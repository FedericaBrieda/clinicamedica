//
//  doctorTableCell.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 17/11/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import UIKit
class doctorTableCell: UITableViewCell {
    
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var startdate: UILabel!
    @IBOutlet weak var finishdate: UILabel!
    @IBOutlet weak var edit: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

  
}
