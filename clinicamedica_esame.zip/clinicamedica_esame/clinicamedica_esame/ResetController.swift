//
//  ResetController.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 10/12/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import Foundation
import Alamofire

class ResetController: UIViewController{
    
    @IBOutlet weak var resetemail: UITextField!
    @IBOutlet weak var sendreset: UIButton!
    @IBOutlet weak var backlogin: UIButton!
    
    @IBAction func sendreset(_ sender: Any) {
        resetPassword()
    }
    
    @IBAction func backlogin(_ sender: Any) {
        backLogin()
    }
    
    func backLogin() {
           DispatchQueue.main.async(execute: {
               self.performSegue(withIdentifier: "returnSegue", sender: nil)
           })
       }
       
    func resetPassword() {
    let url = URL(string: "http://clinicamedica/api/send-mail")!
    let params:[String:String] = ["email" : "\(resetemail.text!)"]
    AF.request(url, method: .post, parameters: params).validate().responseJSON { response in
        if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
            print("Data: \(utf8Text)")
            
            guard response.error == nil
                else {
                    print(response.error!)
                    return
            }
            guard (response.value as? [String:Any]) != nil
                else {
                    if let error = response.error {
                       
                        print("ERRORE: \(error)")
                    }
                    return
            }
            
            guard let response = response.value else {
               
                print("error")
                return
            }
            
            self.backLogin()
        }
}
}
}
