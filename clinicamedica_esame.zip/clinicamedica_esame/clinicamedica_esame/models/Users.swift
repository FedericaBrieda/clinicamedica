//
//  Reservation.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 18/11/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import Foundation

class Users: Codable {

       var name: String
       var username: String
       var email: String
       var type: String
    
    
    init(name: String,username:String,email:String, type:String){
        
        self.name = name
        self.username = username
        self.email = email
        self.type = type

    }
}
class UserData: Codable {
       var data: [Users]?
       init(data:[Users]) {
           self.data = data
       }
   }
