//
//  Reservation.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 18/12/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import Foundation

struct Resevation: Codable {
    
    var reservation: [Reservation]
    
    init(reservation: [Reservation]) {
        self.reservation = reservation
    }
}

struct Reservation: Codable {
    
    var startdate:String
    var finishdate:String
    var status:String
    var service: [Service]?
    
    
    init(startdate: String,finishdate:String,status:String, service:[Service]){
        
        self.startdate = startdate
        self.finishdate = finishdate
        self.status = status
        self.service = service
    }
    
    
}
//struct ReservationData: Codable {
//       var data: [Reservation]?
//       init(data:[Reservation]) {
//           self.data = data
//       }
//   }

