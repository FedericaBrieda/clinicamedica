//
//  Reservation.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 18/12/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import Foundation

//struct

struct Service: Codable{
    
    var name:String
    var price:Double
    
     init(name:String,price:Double){
        
        self.name = name
        self.price = price
    }
}

class ServiceData: Codable {
    var data: [Service]
    init(data:[Service]) {
        self.data = data
    }
}
