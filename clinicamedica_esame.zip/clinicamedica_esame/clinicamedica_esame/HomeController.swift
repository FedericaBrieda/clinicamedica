//
//  HomeController.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import UIKit
import Alamofire

class HomeController: UIViewController,UITableViewDataSource, UITableViewDelegate{
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var add: UIBarButtonItem!
    @IBOutlet weak var profile: UIBarButtonItem!
    
    var reservations: [Reservation] = []

    override func viewDidLoad() {
            super.viewDidLoad()
        fetchReservations(complete: {(reservations) in
//            self.reservations = reservations
            let queue = DispatchQueue.main
            queue.async(execute:{
                self.tableView.delegate = self
                self.tableView.dataSource = self
                self.tableView.reloadData()
            })
        })
        
    }
    
    
    //NUMERO DI RIGHE
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            reservations.count
    }
           //OGNI CELLA
           func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            var cell: UITableViewCell?
            let reservationCell = tableView.dequeueReusableCell(withIdentifier: "ReservationCell", for: indexPath)as! doctorTableCell
            let reservation = reservations[indexPath.row]
            reservationCell.name!.text = reservation.service?[0].name
            reservationCell.status!.text = reservation.status
            reservationCell.startdate!.text = reservation.startdate
            reservationCell.finishdate!.text = reservation.finishdate

            return reservationCell
            
           }
       
    
    func fetchReservations(complete: @escaping (_ result: [Reservation])->()) {
    let url = URL(string: "http://clinicamedica.test/api/reservation")!
   AF.request(url, method: .get).validate().responseJSON { response in
        if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
            print("Data: \(utf8Text)")

            do{
                self.reservations = try JSONDecoder().decode([Reservation].self, from: response.data!)
                complete([reservations])
            }
             catch let eroor {
                   print(eroor)
                return
            }

    }
        }
    }
    }

    

