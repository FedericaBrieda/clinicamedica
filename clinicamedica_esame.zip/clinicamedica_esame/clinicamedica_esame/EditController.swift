//
//  HomeController.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda on 17/11/2019.
//  Copyright © 2019 Federica Brieda. All rights reserved.
//

import UIKit
import Alamofire

class EditController: UIViewController{
   
    var reservations = [Reservation]()
   
    @IBOutlet var nameedit: UIView!
    @IBOutlet weak var statusedit: UITextField!
    @IBOutlet weak var datastartedit: UITextField!
    @IBOutlet weak var datafinishedit: UITextField!
    @IBOutlet weak var buttonsave: UIButton!
    @IBOutlet weak var buttondelete: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func buttonsave(_ sender: Any) {
        
    }
    
    @IBAction func buttondelete(_ sender: Any) {
    }
    
}
