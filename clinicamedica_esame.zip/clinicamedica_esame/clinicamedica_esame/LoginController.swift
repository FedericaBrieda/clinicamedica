//
//  LoginController.swift
//  clinicamedica_esame
//
//  Created by Federica Brieda
//  Copyright © 2020 Federica Brieda. All rights reserved.
//

import Foundation
import Alamofire

class LoginController: UIViewController {

  
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var enter: UIButton!
    @IBOutlet weak var remberpassword: UIButton!
    
    override func viewDidLoad() {
               super.viewDidLoad()
    }

}

